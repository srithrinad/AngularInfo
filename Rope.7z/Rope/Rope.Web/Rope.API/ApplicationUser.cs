﻿using Microsoft.AspNetCore.Identity;

namespace Rope
{
    public class ApplicationUser : IdentityUser
    {
        public const string AdministratorClaim = "Administrator";
    }
}
