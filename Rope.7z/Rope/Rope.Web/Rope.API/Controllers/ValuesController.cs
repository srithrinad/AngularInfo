﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Rope.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public IActionResult ValidateToken()
        {
            return Ok();
        }

        [AllowAnonymous]
        [HttpGet("IsLoggedIn")]
        public Boolean IsLoggedIn()
        {
            return User.Identity.IsAuthenticated;
        }
    }
}
