﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using crm.Domain;

namespace crm.DataAccess
{
    public class CrmUsersDbContext : DbContext
    {
        public CrmUsersDbContext(DbContextOptions<CrmUsersDbContext> options) : base(options)
        {
        }


        public DbSet<CrmUser> CrmUsers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CrmUser>().ToTable("users");
        }
    }
}
