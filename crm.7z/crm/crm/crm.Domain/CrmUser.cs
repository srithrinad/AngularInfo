﻿using System;
using System.Collections.Generic;
using System.Text;

namespace crm.Domain
{
    public class CrmUser
    {
        public int Id { get; set; }
        public string AspNetUsersId { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public string LasName { get; set; }
        public string MiddleName { get; set; }
        public string Email { get; set; }
    }
}
