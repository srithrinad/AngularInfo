﻿using crm.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace crm.DataAccess
{
    public class LookupTableBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }
    }


    [Table("Permissions")]
    public class _Permissions : LookupTableBase { }


    public class CrmUsersDbContextExtender
    {

        public void bindEnumDatatoModelBuilder(ModelBuilder modelBuilder)
        {
            foreach (Permissions val in Enum.GetValues(typeof(Permissions)))
            {
                modelBuilder.Entity<_Permissions>().HasData(new _Permissions
                {
                    Id = (int)val,
                    Name = Enum.GetName(typeof(Permissions), val).ToString()
                });
            }
        }
    }
}
