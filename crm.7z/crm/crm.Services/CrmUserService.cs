﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using crm.DataAccess;
using crm.Domain;
using crm.Dtos;
using System.Threading.Tasks;

namespace crm.Services
{
    public class CrmUserService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private CrmUsersDbContext _db;

        public CrmUserService(CrmUsersDbContext crmUsersDbContext, UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
            _db = crmUsersDbContext;
        }

        public async Task<IdentityResult> SignUp(SignUpDto signUpDto)
        {
            if (signUpDto.Id != 0)
            {
                throw new InvalidOperationException("User already exist");
            }

            var appUser = new ApplicationUser
            {
                UserName = signUpDto.Email,
                Email = signUpDto.Email,
            };

            var result = await _userManager.CreateAsync(appUser, signUpDto.password);

            if (result.Succeeded)
            {
                try
                {
                    signUpDto.AspNetUsersId = appUser.Id;
                    _db.Add(signUpDto);
                    _db.SaveChanges();
                    //await Repository.InsertAsync(portalUser);
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.InnerException);
                    throw;
                }
            }

            return result;
        }




    }
}
