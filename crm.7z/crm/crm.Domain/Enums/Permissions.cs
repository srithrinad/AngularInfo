﻿using System;
using System.Collections.Generic;
using System.Text;

namespace crm.Domain
{
    public enum Permissions
    {
        NotAllowed = 0,
        Add = 1,
        ReadOnly = 2,
        Edit = 3
    }
}
