﻿using System;
using System.Collections.Generic;
using System.Text;

namespace crm.Domain
{
    public enum PermissionEnum
    {
        NotAllowed = 0,
        Add = 1,
        ReadOnly = 2,
        Edit = 3
    }
}
