﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace crm.Domain
{
    public class ApplicationUser : IdentityUser
    {
        public const bool IsAdmin = false;
    }
}
