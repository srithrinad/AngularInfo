﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace crm.Domain
{
    public class ApplicationUser : IdentityUser
    {
        public const bool IsAdmin = false;
    }
}
