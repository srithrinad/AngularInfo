﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using crm.Domain;

namespace crm.Api.Auth
{
    public class PermissionAuth : IAuthorizationRequirement
    {
        public int MinimumAge { get; }

        public PermissionAuth(PermissionEnum permission)
        {
            Permission = permission;
        }

        public PermissionEnum Permission { get; }
    }
}
