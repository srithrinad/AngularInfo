﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using crm.Services;
using crm.Dtos;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace crm.Api.Controllers
{
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class RegistrationController : Controller
    {
        private readonly CrmUserService _crmUserService;

        public RegistrationController(CrmUserService crmUserService)
        {
            _crmUserService = crmUserService;
        }

        [HttpPost("SignUp"),]
        public async Task<IActionResult> SignUp([FromBody] SignUpDto dto)
        {
            var identityResult = await _crmUserService.SignUp(dto);
            return Ok(identityResult);

//            {
//                'password' : 'P@ssword123',
//"email" : "ithrinad@gmail.com",
//"userId" : "ithrinad@gmail.com",
//"name" : "ithrinad@gmail.com"
//}
        }

    }
}
