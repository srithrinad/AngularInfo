﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.AspNet.OData.Query;
using crm.DataAccess;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace crm.Api.Controllers
{
    [Route("api/[controller]")]
    [ODataRoutePrefix("CrmUser")]
    public class CrmUserController : ODataController
    {
        // GET: api/<controller>

        private CrmUsersDbContext _db;

        public CrmUserController(CrmUsersDbContext crmUsersDbContext)
        {
            _db = crmUsersDbContext;
        }


        [ODataRoute]
        [EnableQuery(PageSize = 20, AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult Get()
        {
            return Ok(_db.CrmUsers.AsQueryable());
        }

        [ODataRoute("({key})")]
        [EnableQuery(PageSize = 20, AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult Get([FromODataUri] int key)
        {
            return Ok(_db.CrmUsers.Find(key));
        }
    }
}
