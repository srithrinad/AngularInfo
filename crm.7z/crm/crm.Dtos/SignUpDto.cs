﻿using System;
using crm.Domain;

namespace crm.Dtos
{
    public class SignUpDto : CrmUser
    {
        public string userId { set; get; }
        public string password { set; get; }
    }
}
