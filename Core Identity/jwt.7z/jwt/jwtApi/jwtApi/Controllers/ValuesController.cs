﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace jwtApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("role/{id}")]   
        [Authorize(Policy = "IsAdmin")]
        public ActionResult<string> role(int id)
        {
            return id.ToString();
        }

        [HttpGet("claim/{id}")]
        [Authorize(Policy = "IsNormalUser")]
        public ActionResult<string> claim(int id)
        {
            return id.ToString();
        }

        [HttpGet("GetPermissionAuth/{id}")]
        [Authorize(Policy = nameof(Permissions.Add))]
        public ActionResult<string> GetPermissionAuth(int id)
        {
            return id.ToString();
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
