﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace jwtApi
{
    public enum Permissions
    {
        NotAllowed = 0,
        Add = 1,
        ReadOnly = 2,
        Edit = 3
    }
    public class CollectionClass
    {
       
    }
}
