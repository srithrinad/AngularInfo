﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace jwtApi
{
    public class PermissionAuthHandler : AuthorizationHandler<PermissionAuth>
    {
        public PermissionAuthHandler()
        {
            

        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionAuth requirement)
        {
           // var allRoles = context.User.Claims.ToList();

            if (requirement.Permission == Permissions.Add)
            {
                context.Succeed(requirement);
            }
            else
            {
                context.Fail();
            }
            return Task.CompletedTask;
        }

    }
}
