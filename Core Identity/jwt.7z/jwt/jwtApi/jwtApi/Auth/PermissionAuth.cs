﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;


namespace jwtApi
{
    public class PermissionAuth : IAuthorizationRequirement
    {
        public PermissionAuth(Permissions permission)
        {
            Permission = permission;
        }

        public Permissions Permission { get; }
    }
}
