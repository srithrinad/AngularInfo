﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quartz;

namespace TricolorCronServices
{
    public class ClearFoldersContentJob:IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            try
            {
                ClearFoldersContent.Execute();

            } catch(Exception ex)
            {
                ExceptionHandler.Manage(" - ClearFoldersContentJob", ex);
            }
        }
  
    }
}
