﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quartz;

namespace TricolorCronServices
{
    public class ClearScannedPagesFolderJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            try
            {
                ClearScannedPages.ClearUnderScoreFiles();
                ClearScannedPages.ClearFilesNotInDB();

            } catch(Exception ex)
            {
                ExceptionHandler.Manage(" - ClearScannedPagesFolderJob", ex);
            }
        }     

    }
}
