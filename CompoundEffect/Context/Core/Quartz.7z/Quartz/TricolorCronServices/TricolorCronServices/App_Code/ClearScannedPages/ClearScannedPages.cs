﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TricolorCronServices
{
    public class ClearScannedPages
    {
        public static void ClearUnderScoreFiles()
        {
            try
            {
                DirectoryInfo d = new DirectoryInfo(Configuration_Manager.clearScannedPagesFolder);
                FileInfo[] Files = d.GetFiles();

                foreach(FileInfo file in Files)
                {
                    if(file.Name.Contains("_"))
                    {
                        file.Delete();
                    }
                }

            } catch(Exception ex)
            {
                throw ex;
            }
        }

        public static void ClearFilesNotInDB()
        {
            try
            {
                DataSet ds = DBClearScannedPages.GetScannedPages();
                List<string> ids = (from row in ds.Tables[0].AsEnumerable()
                                    select Convert.ToString(row["scanned_page_id"])).ToList();

                DirectoryInfo d = new DirectoryInfo(Configuration_Manager.clearScannedPagesFolder);
                FileInfo[] Files = d.GetFiles();
                string fileName_Local = "";

                foreach(FileInfo file in Files)
                {
                    if(!file.Name.Contains("_"))
                    {
                        fileName_Local = Path.GetFileNameWithoutExtension(file.Name);

                        if(ids.FindAll(fileName_DB => fileName_DB == fileName_Local).Count > 0)
                        {

                        }
                        else
                        {
                            file.Delete();
                        }
                    }
                }

            } catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
