﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class ExceptionHandler
{
    public static void Manage(string subject, Exception ex)
    {
        MailServices obj_ms = new MailServices();

        try
        {
            string mail_to = Configuration_Manager.errorMailTo;
            string ref_error = "";

            Utils.Writetolog(subject + " -- " + ex.ToString());
            EMailService.send(mail_to, Configuration_Manager.mailFromAddress, Configuration_Manager.errorMailSubject + " " + subject, Configuration_Manager.mailDisplayName, ex.ToString(), null, ref ref_error);

        } catch
        {
        }
    }
}
