﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Utils
{

    public static void GetAllFilesFromDirectoryAndSubDirectories(string targetDirectory, List<String> fileList)
    {
        try
        {
            foreach(string f in Directory.GetFiles(targetDirectory))
            {
                fileList.Add(f);
            }
            foreach(string d in Directory.GetDirectories(targetDirectory))
            {
                GetAllFilesFromDirectoryAndSubDirectories(d, fileList);
            }

        } catch(Exception ex)
        {

        }
    }

    public static void GetAllFilesFromDirectory(string targetDirectory, List<String> fileList)
    {
        try
        {
            foreach(string f in Directory.GetFiles(targetDirectory))
            {
                fileList.Add(f);
            }      

        } catch(Exception ex)
        {

        }
    }



    public static void Writetolog(string log_message)
    {
        if(log_message.ToLower().Contains("thread was being aborted"))
            return;

        StreamWriter sw;
        string FilePath = Configuration_Manager.serviceErrorPath;
        string Path = FilePath + "ContentClearError.log";
        if(File.Exists(Path))
        {
            sw = File.AppendText(Path);
        }
        else
        {
            sw = File.CreateText(Path);
        }

        try
        {
            sw.WriteLine(string.Format("{0:MM/dd/yyyy hh:mm:ss}", System.DateTime.Now) + " @ " + log_message);
            sw.WriteLine("-------------------------------------------------------------------------");
            sw.Flush();
            sw.Close();

        } catch(Exception ex)
        {            
            sw.Flush();
            sw.Close();
        }
        finally
        {
            if(sw == null)
            {
                sw.Flush();
                sw.Close();
            }
        }
    }


}

