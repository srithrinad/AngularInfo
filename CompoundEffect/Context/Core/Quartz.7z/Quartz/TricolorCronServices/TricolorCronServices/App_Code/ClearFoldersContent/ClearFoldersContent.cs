﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TricolorCronServices
{
    public class ClearFoldersContent
    {
        public static void Execute()
        {
            try
            {
                string[] folderList = Configuration_Manager.clearFoldersContent.Split(',');
                foreach(string targetDirectory in folderList)
                {
                    List<String> fileList = new List<String>();
                    Utils.GetAllFilesFromDirectoryAndSubDirectories(targetDirectory, fileList);
                    foreach(string str_file in fileList)
                    {
                        File.Delete(str_file);
                    }
                }

            } catch(Exception ex)
            {
                throw ex;
            }
        }        
    }
}