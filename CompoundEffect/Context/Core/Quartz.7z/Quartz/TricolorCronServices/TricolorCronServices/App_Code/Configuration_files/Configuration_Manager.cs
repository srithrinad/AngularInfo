﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

public class Configuration_Manager
{
    protected static string GetAppValue(string str)
    {
        return Convert.ToString(ConfigurationManager.AppSettings[str]);
    }
    public static string DBConnectionString
    {
        get
        {
            return Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
        }
    }

    public static string smtpMailServer
    {
        get
        {
            return GetAppValue("smtpMailServer");
        }
    }
    public static string smtpUserId
    {
        get
        {
            return GetAppValue("smtpUserId");
        }
    }
    public static string smtpPwd
    {
        get
        {
            return GetAppValue("smtpPwd");
        }
    }

    public static string mailFromAddress
    {
        get
        {
            return GetAppValue("mailFromAddress");
        }
    }
    public static string mailDisplayName
    {
        get
        {
            return GetAppValue("mailDisplayName");
        }
    }
    public static string errorMailSubject
    {
        get
        {
            return GetAppValue("errorMailSubject");
        }
    }
    public static string errorMailTo
    {
        get
        {
            return GetAppValue("errorMailTo");
        }
    }


    public static string serviceErrorPath
    {
        get
        {
            return GetAppValue("serviceErrorPath");
        }
    }
    public static string clearFoldersContent
    {
        get
        {
            return GetAppValue("clearFoldersContent");
        }
    }
    public static string clearScannedPagesFolder
    {
        get
        {
            return GetAppValue("clearScannedPagesFolder");
        }
    }


}
