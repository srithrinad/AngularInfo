﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Collections;
using System.IO;

/// <summary>
///  Created by Sritrinad for sending Email 
/// </summary>

public class MailServices
{

    #region Properties
    //-- SMTP Details
    public string SmtpMailServer;
    public string SmtpUserName;
    public string SmptPwd;

    //-- Mail Details
    public string MailFrom;
    public string MailFromDisplayName;
    public string MailTo;
    public string MailSubject;
    public string MailBody;
    public bool IsBodyHtml;
    public List<Attachements> Attachements = new List<Attachements>();
    public string MailCC;
    #endregion

    public MailServices()
    {

    }

    public bool SendGeneralMails(ref Exception MailError)
    {
        bool Result = false;
        MailMessage mail = new MailMessage();
        try
        {
            SmtpClient sc = new SmtpClient(SmtpMailServer);
            String smptUser = SmtpUserName;
            String smptPassword = SmptPwd;
            sc.Credentials = new System.Net.NetworkCredential(smptUser, smptPassword);
            mail.To.Add(MailTo);
            mail.Subject = MailSubject;
            mail.Body = MailBody;

            if(!string.IsNullOrEmpty(MailCC))
                mail.CC.Add(MailCC);

            AlternateView MailplainView = AlternateView.CreateAlternateViewFromString(Regex.Replace(MailBody, @"<(.|\n)*?>", String.Empty), null, "text/plain");
            AlternateView MailhtmlView = AlternateView.CreateAlternateViewFromString(MailBody, null, "text/html");
            mail.BodyEncoding = System.Text.Encoding.GetEncoding("utf-8");

            mail.AlternateViews.Add(MailplainView);
            mail.AlternateViews.Add(MailhtmlView);

            if(Attachements != null)
            {
                foreach(Attachements str in Attachements)
                {
                    FileStream fs = File.OpenRead(str.file_path + str.file_name);
                    mail.Attachments.Add(new Attachment(fs, str.file_name));
                }
            }

            mail.IsBodyHtml = IsBodyHtml;
            mail.From = new MailAddress(MailFrom, MailFromDisplayName);
            sc.Send(mail);
            Result = true;

        } catch(Exception ex)
        {
            Result = false;
            MailError = ex;
        }
        finally
        {
            mail.Dispose();
        }

        return Result;
    }
}

public class Attachements
{
    public string file_name = "";
    public string file_path = "";

    public Attachements()
    {

    }

    public Attachements(string filename, string filepath)
    {
        this.file_name = filename;
        this.file_path = filepath;
    }
}

public class EMailService
{
    public static bool send(string mail_to, string from, string subject, string displayName, string mail_text, List<Attachements> Attachements, ref string error_msg)
    {
        bool result = false;
        MailServices obj_ms = new MailServices();

        try
        {
            obj_ms.SmtpMailServer = Configuration_Manager.smtpMailServer;
            obj_ms.SmtpUserName = Configuration_Manager.smtpUserId;
            obj_ms.SmptPwd = Configuration_Manager.smtpPwd;
            obj_ms.MailSubject = subject;
            obj_ms.MailFrom = from;
            obj_ms.MailFromDisplayName = displayName;
            obj_ms.MailTo = mail_to;
            obj_ms.MailBody = mail_text;
            obj_ms.IsBodyHtml = true;
            obj_ms.Attachements = Attachements;


            Exception error = new Exception();

            if(obj_ms.SendGeneralMails(ref error))
            {
                result = true;
            }
            else
            {
                result = false;
                throw error;
            }

        } catch(Exception ex)
        {
            error_msg = ex.ToString();
        }

        return result;
    }
}




