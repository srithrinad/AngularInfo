﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

namespace TricolorCronServices
{
    class DBClearScannedPages
    {
        public static DataSet GetScannedPages()
        {
            DataSet ds = new DataSet();
            SqlCommand sqlcmd = new SqlCommand("select scanned_page_id from [dbo].[dss_scanned_pages]");
            sqlcmd.Connection = new SqlConnection(Configuration_Manager.DBConnectionString);
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandTimeout = 500;
            SqlDataAdapter result = new SqlDataAdapter(sqlcmd);
            result.Fill(ds);
            return ds;
        }
    }
}
