﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Quartz.Impl;
using Quartz.Simpl;
using Quartz.Xml;


namespace TricolorCronServices
{
    public partial class ClearContentService:ServiceBase
    {

        public ClearContentService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            StartService();
        }

        protected override void OnStop()
        {
        }


        public void StartService()
        {
            try
            {
                //Quartz.net scheduler
                var schedulerFactory = new StdSchedulerFactory();
                var scheduler = schedulerFactory.GetScheduler();
                scheduler.Start();
                new XMLSchedulingDataProcessor(new SimpleTypeLoadHelper()).ProcessFileAndScheduleJobs(scheduler, true);

            } catch(Exception ex)
            {
                ExceptionHandler.Manage(" - StartService", ex);
            }
        }

    }
}
