﻿using System;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Hangfire.RecurringJobExtensions
{
	internal static class TypeExtensions
	{
		public static string GetRecurringJobId(this MethodInfo method)
		{
			return $"{method.DeclaringType.ToGenericTypeString()}.{method.Name}";
		}
		/// <summary>
		/// Fork the extension method from 
		/// https://github.com/HangfireIO/Hangfire/blob/master/src/Hangfire.Core/Common/TypeExtensions.cs
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public static string ToGenericTypeString(this Type type)
		{
			if (!type.GetTypeInfo().IsGenericType)
			{
				return type.GetFullNameWithoutNamespace()
						.ReplacePlusWithDotInNestedTypeName();
			}

			return type.GetGenericTypeDefinition()
					.GetFullNameWithoutNamespace()
					.ReplacePlusWithDotInNestedTypeName()
					.ReplaceGenericParametersInGenericTypeName(type);
		}
		private static string GetFullNameWithoutNamespace(this Type type)
		{
			if (type.IsGenericParameter)
			{
				return type.Name;
			}

			const int dotLength = 1;
			// ReSharper disable once PossibleNullReferenceException
			return !String.IsNullOrEmpty(type.Namespace)
				? type.FullName.Substring(type.Namespace.Length + dotLength)
				: type.FullName;
		}
		private static string ReplacePlusWithDotInNestedTypeName(this string typeName)
		{
			return typeName.Replace('+', '.');
		}
		private static string ReplaceGenericParametersInGenericTypeName(this string typeName, Type type)
		{
			var genericArguments = type.GetTypeInfo().GetAllGenericArguments();

			const string regexForGenericArguments = @"`[1-9]\d*";

			var rgx = new Regex(regexForGenericArguments);

			typeName = rgx.Replace(typeName, match =>
			{
				var currentGenericArgumentNumbers = int.Parse(match.Value.Substring(1));
				var currentArguments = string.Join(",", genericArguments.Take(currentGenericArgumentNumbers).Select(ToGenericTypeString));
				genericArguments = genericArguments.Skip(currentGenericArgumentNumbers).ToArray();
				return string.Concat("<", currentArguments, ">");
			});

			return typeName;
		}
		public static Type[] GetAllGenericArguments(this TypeInfo type)
		{
			return type.GenericTypeArguments.Length > 0 ? type.GenericTypeArguments : type.GenericTypeParameters;
		}
	}
}
