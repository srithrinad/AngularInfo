﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace GenerateScripts
{
    public partial class BtnGetDbObjects : Form
    {
        public BtnGetDbObjects()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnGenerateScript_Click(object sender, EventArgs e)
        {

            if (txtConnString.Text.Trim() == "")
            {
                MessageBox.Show("Enter SQL Connection String ");
            }
            else
            {
                GenerateScript();
            }
        }



        private void btnReset_Click(object sender, EventArgs e)
        {          
            txtConnString.Text = "";
            txtPath.Text = "";
            ChkStoredProceduresList.Items.Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {           
            this.Close();
        }

        public static string GetDateTime()
        {
            return "Date" + System.DateTime.Now.Day.ToString() + "-" + System.DateTime.Now.Month.ToString() + "-" + System.DateTime.Now.Year.ToString() + "-" + "Time" + System.DateTime.Now.Hour.ToString() + "-" + System.DateTime.Now.Minute.ToString() + "-" + System.DateTime.Now.Second.ToString();
        }

        private void GenerateScript()
        {
            if (ChkStoredProceduresList.CheckedItems.Count > 0)
            {
                string fileName = "\\GeneratedScript_" + GetDateTime() + ".sql";
                string path = txtPath.Text.Trim() + "\\" + fileName;
                StreamWriter sw;

              

                foreach (var chktem in ChkStoredProceduresList.CheckedItems)
                {
                    string CommandText = "SP_HELPTEXT  " + chktem.ToString().Replace("Sproc-","").Replace("Function-", "");

                    if (File.Exists(path))
                    {
                        sw = File.AppendText(path);
                    }
                    else
                    {
                        sw = File.CreateText(path);
                    }

                    try
                    {
                        using (SqlConnection con = new SqlConnection(txtConnString.Text.Trim()))
                        {
                            using (SqlCommand cmd = new SqlCommand(CommandText, con))
                            {
                                cmd.CommandType = CommandType.Text;
                                cmd.Connection.Open();

                                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                             
                                string lineString = "";

                                while (dr.Read())
                                {
                                    lineString = dr[0].ToString().Trim().ToLower().Replace("\t", "").Replace("\n", "");
                                    if (lineString != "")
                                    {
                                        sw.Write(dr[0].ToString());
                                    }
                                }
                                sw.WriteLine("");
                                sw.WriteLine("GO");
                                sw.WriteLine("");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        sw.Flush();
                        sw.Close();
                    }
                    finally
                    {
                        if (sw == null)
                        {
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }


                MessageBox.Show(@"Scripts " + fileName  + " Generated Successfully");
                
            }
        }    

        private void btnGetDBObject_Click(object sender, EventArgs e)
        {
            ChkStoredProceduresList.Items.Clear();
            if (ChkDbObject.CheckedItems.Count > 0)
            {
                foreach (var chkType in ChkDbObject.CheckedItems)
                {
                    switch (chkType)
                    {
                        case "Functions":
                            GetFunctionsList();
                            break;
                        case "Stored Procedures":
                            GetStoredProceduresList();
                            break;
                    }
                }
            }
        }

        private void GetFunctionsList()
        {
            string CommandText = "SELECT name , SCHEMA_NAME(schema_id) AS schema_name  , type_desc FROM sys.objects WHERE type_desc LIKE '%FUNCTION%'  ORDER BY type_desc";

            using (SqlConnection con = new SqlConnection(txtConnString.Text.Trim()))
            {
                using (SqlCommand cmd = new SqlCommand(CommandText, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection.Open();

                    SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    while (dr.Read())
                    {
                        ChkStoredProceduresList.Items.Add("Function-" + dr["name"].ToString());
                    }
                }
            }
        }

        private void GetStoredProceduresList()
        {

            string CommandText = "SELECT name, type FROM dbo.sysobjects WHERE (type = 'P') AND LEFT(name, 3) NOT IN ('sp_', 'xp_', 'ms_') ORDER BY [Name]";

            using (SqlConnection con = new SqlConnection(txtConnString.Text.Trim()))
            {
                using (SqlCommand cmd = new SqlCommand(CommandText, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection.Open();

                    SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    while (dr.Read())
                    {
                        ChkStoredProceduresList.Items.Add("Sproc-" + dr["name"].ToString());
                    }
                }
            }
        }

        private void btnSelectAllDbObjectResult_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < ChkStoredProceduresList.Items.Count; i++)
            {
                ChkStoredProceduresList.SetItemChecked(i, true);
            }
        }



        //private void GenerateStoredProc(string ProcName)
        //{
        //    if (System.IO.Directory.Exists(txtPath.Text.Trim()) == false)
        //    {
        //        System.IO.Directory.CreateDirectory(txtPath.Text.Trim());
        //    }
        //    SqlConnection con = new SqlConnection(txtConnString.Text.Trim());

        //    SqlCommand cmd = new SqlCommand("SP_HELPTEXT " + ProcName, con);
        //    cmd.CommandType = CommandType.Text;
        //    cmd.Connection.Open();

        //    SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        //    string path = txtPath.Text.Trim() + ProcName + ".sql";

        //    FileStream fs = new FileStream(txtPath.Text.Trim() + ProcName + ".sql", FileMode.OpenOrCreate, FileAccess.ReadWrite);
        //    StreamWriter sw = new StreamWriter(fs, Encoding.Default);
        //    string lineString = "";

        //    while (dr.Read())
        //    {
        //        lineString = dr[0].ToString().Trim().ToLower().Replace("\t", "").Replace("\n", "");
        //        if (lineString != "")
        //        {
        //            sw.Write(dr[0].ToString());
        //        }
        //    }
        //    sw.Close();
        //    fs.Close();
        //}

        //private void GenerateTableScripts(string TableName)
        //{
        //    if (System.IO.Directory.Exists(txtPath.Text.Trim()) == false)
        //    {
        //        System.IO.Directory.CreateDirectory(txtPath.Text.Trim());
        //    }
        //    SqlConnection con = new SqlConnection(txtConnString.Text.Trim());

        //    SqlCommand cmd = new SqlCommand("EXEC sp_ScriptTable " + TableName, con);
        //    cmd.CommandType = CommandType.Text;
        //    cmd.Connection.Open();

        //    SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

        //    string path = txtPath.Text.Trim() + TableName + ".sql";

        //    FileStream fs = new FileStream(txtPath.Text.Trim() + TableName + ".sql", FileMode.OpenOrCreate, FileAccess.ReadWrite);
        //    StreamWriter sw = new StreamWriter(fs, Encoding.Default);

        //    while (dr.Read())
        //    {
        //        sw.WriteLine(dr[0].ToString());
        //    }
        //    sw.Close();
        //    fs.Close();
        //}
    }
}
