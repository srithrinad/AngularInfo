﻿namespace GenerateScripts
{
    partial class BtnGetDbObjects
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGenerateScript = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblConnString = new System.Windows.Forms.Label();
            this.txtConnString = new System.Windows.Forms.TextBox();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.ChkDbObject = new System.Windows.Forms.CheckedListBox();
            this.btnGetDBObject = new System.Windows.Forms.Button();
            this.ChkStoredProceduresList = new System.Windows.Forms.CheckedListBox();
            this.btnSelectAllDbObjectResult = new System.Windows.Forms.Button();
            this.lblPath = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGenerateScript
            // 
            this.btnGenerateScript.Location = new System.Drawing.Point(430, 146);
            this.btnGenerateScript.Name = "btnGenerateScript";
            this.btnGenerateScript.Size = new System.Drawing.Size(492, 40);
            this.btnGenerateScript.TabIndex = 2;
            this.btnGenerateScript.Text = "GenerateScripts";
            this.btnGenerateScript.UseVisualStyleBackColor = true;
            this.btnGenerateScript.Click += new System.EventHandler(this.btnGenerateScript_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(1121, 64);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 49);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Clear";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(1121, 19);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 39);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblConnString
            // 
            this.lblConnString.AutoSize = true;
            this.lblConnString.Location = new System.Drawing.Point(13, 22);
            this.lblConnString.Name = "lblConnString";
            this.lblConnString.Size = new System.Drawing.Size(91, 13);
            this.lblConnString.TabIndex = 5;
            this.lblConnString.Text = "Connection String";
            // 
            // txtConnString
            // 
            this.txtConnString.Location = new System.Drawing.Point(110, 19);
            this.txtConnString.Name = "txtConnString";
            this.txtConnString.Size = new System.Drawing.Size(914, 20);
            this.txtConnString.TabIndex = 6;
            this.txtConnString.Text = "Data Source=67.79.113.229;Initial Catalog=SafeHarborMarinasDev;User ID=tekzenit1;" +
    "Password=Win*The*Gold**&@;MultipleActiveResultSets=true";
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(540, 107);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(382, 20);
            this.txtPath.TabIndex = 8;
            this.txtPath.Text = "C:\\Users\\thrinadha.rao\\Desktop\\db Script\\";
            // 
            // ChkDbObject
            // 
            this.ChkDbObject.FormattingEnabled = true;
            this.ChkDbObject.Items.AddRange(new object[] {
            "Functions",
            "Stored Procedures"});
            this.ChkDbObject.Location = new System.Drawing.Point(16, 58);
            this.ChkDbObject.Name = "ChkDbObject";
            this.ChkDbObject.Size = new System.Drawing.Size(132, 49);
            this.ChkDbObject.TabIndex = 9;
            // 
            // btnGetDBObject
            // 
            this.btnGetDBObject.Location = new System.Drawing.Point(154, 58);
            this.btnGetDBObject.Name = "btnGetDBObject";
            this.btnGetDBObject.Size = new System.Drawing.Size(162, 49);
            this.btnGetDBObject.TabIndex = 10;
            this.btnGetDBObject.Text = "Get DB Object";
            this.btnGetDBObject.UseVisualStyleBackColor = true;
            this.btnGetDBObject.Click += new System.EventHandler(this.btnGetDBObject_Click);
            // 
            // ChkStoredProceduresList
            // 
            this.ChkStoredProceduresList.FormattingEnabled = true;
            this.ChkStoredProceduresList.Location = new System.Drawing.Point(16, 162);
            this.ChkStoredProceduresList.Name = "ChkStoredProceduresList";
            this.ChkStoredProceduresList.Size = new System.Drawing.Size(300, 439);
            this.ChkStoredProceduresList.TabIndex = 11;
            // 
            // btnSelectAllDbObjectResult
            // 
            this.btnSelectAllDbObjectResult.Location = new System.Drawing.Point(16, 125);
            this.btnSelectAllDbObjectResult.Name = "btnSelectAllDbObjectResult";
            this.btnSelectAllDbObjectResult.Size = new System.Drawing.Size(300, 23);
            this.btnSelectAllDbObjectResult.TabIndex = 12;
            this.btnSelectAllDbObjectResult.Text = "Select All";
            this.btnSelectAllDbObjectResult.UseVisualStyleBackColor = true;
            this.btnSelectAllDbObjectResult.Click += new System.EventHandler(this.btnSelectAllDbObjectResult_Click);
            // 
            // lblPath
            // 
            this.lblPath.AutoSize = true;
            this.lblPath.Location = new System.Drawing.Point(427, 110);
            this.lblPath.Name = "lblPath";
            this.lblPath.Size = new System.Drawing.Size(107, 13);
            this.lblPath.TabIndex = 7;
            this.lblPath.Text = "Set path to generate ";
            // 
            // BtnGetDbObjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1228, 608);
            this.Controls.Add(this.btnSelectAllDbObjectResult);
            this.Controls.Add(this.ChkStoredProceduresList);
            this.Controls.Add(this.btnGetDBObject);
            this.Controls.Add(this.ChkDbObject);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.lblPath);
            this.Controls.Add(this.txtConnString);
            this.Controls.Add(this.lblConnString);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnGenerateScript);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "BtnGetDbObjects";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnGenerateScript;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblConnString;
        private System.Windows.Forms.TextBox txtConnString;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.CheckedListBox ChkDbObject;
        private System.Windows.Forms.Button btnGetDBObject;
        private System.Windows.Forms.CheckedListBox ChkStoredProceduresList;
        private System.Windows.Forms.Button btnSelectAllDbObjectResult;
        private System.Windows.Forms.Label lblPath;
    }
}

