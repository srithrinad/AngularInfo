﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace CoreBase
{
    public interface IRepository<TEntity> where TEntity : class
    {

        Task<IEnumerable<TEntity>> GetAll();

        Task<TEntity> FindAsync(params object[] keyValues);

        Task InsertAsync(TEntity entity);

        Task UpdateAsync(TEntity entity);

        Task Delete(TEntity entity);

        Task InsertAsync(IEnumerable<TEntity> entity);

        Task UpdateAsync(IEnumerable<TEntity> entity);

        Task Delete(IEnumerable<TEntity> entity);

    }
}
