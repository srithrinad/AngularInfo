﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace CoreBase
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity :class
    {
        protected readonly DbContext _dbContext;
        private readonly DbSet<TEntity> _dbSet;

        public Repository(DbContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _dbSet = _dbContext.Set<TEntity>();
        }

        public async Task<IEnumerable<TEntity>> GetAll()
        {
            return await _dbSet.ToListAsync<TEntity>();
        }


        public async Task<TEntity> FindAsync(params object[] keyValues)
        {
            return await _dbContext.FindAsync<TEntity>(keyValues);
           // return await _dbContext.FindAsync _dbSet.FindAsync(keyValues);
        }


        // -- 

        public async Task InsertAsync(TEntity entity)
        {
            await _dbContext.AddAsync<TEntity>(entity);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(TEntity entity)
        {
             _dbContext.Update<TEntity>(entity);
            await _dbContext.SaveChangesAsync();
        }

        public async Task Delete(TEntity entity)
        {
            _dbContext.Remove<TEntity>(entity);
            await _dbContext.SaveChangesAsync();
        }

        // -- 

        public async Task InsertAsync(IEnumerable<TEntity> entities)
        {
            await _dbContext.AddAsync(entities);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(IEnumerable<TEntity> entities)
        {
            _dbContext.UpdateRange(entities);
            await _dbContext.SaveChangesAsync();
        }

        public async Task Delete(IEnumerable<TEntity> entities)
        {
            _dbContext.RemoveRange(entities);
            await _dbContext.SaveChangesAsync();
        }

    }
}
