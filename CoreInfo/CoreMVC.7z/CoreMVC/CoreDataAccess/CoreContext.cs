﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore.SqlServer;
using System.Reflection;
using CoreDomain;

namespace CoreDataAccess
{
    public class CoreContext : DbContext
    {
        private readonly IConfiguration configuration;
        public CoreContext(DbContextOptions<CoreContext> options, IConfiguration config)
            : base(options)
        {
            configuration = config;
        }

       
        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            if (!builder.IsConfigured)
            {              
                string connectionString = configuration.GetConnectionString("DefaultConnection");
                builder.UseSqlServer(connectionString);
            }

            base.OnConfiguring(builder);
        }

        public DbSet<Users> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        }
    }
}
