﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBase;
using CoreDomain;

namespace CoreDataAccess
{
    public class UserRepository : Repository<Users>
    {
        public UserRepository(CoreContext context)
           : base(context)
        {

        }
    }
}
