﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreMVC.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using CoreMVC.Models.Services;
using CoreMVC.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Rendering;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;
using Microsoft.AspNetCore.Http.Headers;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using CoreDomain;
using CoreServices;

namespace CoreMVC.Controllers
{
    public class LoginController : Controller
    {
        private readonly IConfiguration configuration;
        public UserService _userService;
        public LoginController(IConfiguration config, UserService userService)
        {
            _userService = userService;
            configuration = config;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            HttpContext.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }



        public async Task<ActionResult> BtnLogin(IFormCollection data)
        {
            if (ModelState.IsValid)
            {
                Users usr;

                //using (var context = new OldCoreMVCContext(configuration))
                //{
                //    UserService sqlData = new UserService();
                    usr = await _userService.AuthenticateUser(data["Email"], data["Password"]);

                    if (usr != null)
                    {
                        HttpContext.Session.SetInt32("IsSignedIn", 1);
                        HttpContext.Session.SetString("UserName", usr.FirstName);
                        HttpContext.Session.Set("UserDetails", usr);

                        var UsersDetails = HttpContext.Session.Get<Users>("UserDetails");

                        if (data["Email"] == "Admin" && data["Password"] == "pwd")
                        {

                            var claims = new List<Claim>
                            {
                                new Claim(ClaimTypes.Name, data["Email"])

                            };

                            claims.Add(new Claim(ClaimTypes.Role, "admin"));                      

                            //Create the identity for the user  
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                            var principal = new ClaimsPrincipal(identity);

                            var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                            return RedirectToAction("Index", "Home");


                            //var url = string.Format("{0}://{1}}", HttpContext.Request.Scheme, HttpContext.Request.Host, HttpContext.Request.Path);
                            //return Redirect(url);

                        }

                   }

                //}            

            }

            return RedirectToAction("Index", "Home");
        }
    }
}