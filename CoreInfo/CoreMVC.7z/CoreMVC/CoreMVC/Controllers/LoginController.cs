﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreMVC.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using CoreMVC.Models.Services;
using CoreMVC.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Rendering;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;
using Microsoft.AspNetCore.Http.Headers;

namespace CoreMVC.Controllers
{
    public class LoginController : Controller
    {
        private readonly IConfiguration configuration;

        public LoginController(IConfiguration config)
        {
            configuration = config;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }



        public ActionResult BtnLogin(IFormCollection data)
        {
            //throw new Exception("exception hanhling");

           
           


            throw new Exception("exception hanhling");
            string referer = HttpContext.Request.Headers["Referer"].ToString();
            //Uri baseUri = new Uri(referer);
        
            return Redirect(referer);

            // return "checking";


            //HttpContext.Session.SetInt32("IsSignedIn", 0);
            //if (ModelState.IsValid)
            //{
            //    Users usr;

            //    using (var context = new CoreMVCContext(configuration))
            //    {
            //        UserServices sqlData = new UserServices(context);
            //        usr = sqlData.AuthenticateUser(data["Email"], data["Password"]);

            //        if (usr != null)
            //        {
            //            HttpContext.Session.SetInt32("IsSignedIn", 1);
            //            HttpContext.Session.SetString("UserName", usr.FirstName);
            //            HttpContext.Session.Set("UserDetails", usr);

            //            var UsersDetails = HttpContext.Session.Get<Users>("UserDetails");
            //        }

            //    }


            //    //var url = string.Format("{0}://{1}{2}{3}",  HttpContext.Request.Scheme, HttpContext.Request.Host, HttpContext.Request.Path, HttpContext.Request.QueryString);
            //    var url = string.Format("{0}://{1}}", HttpContext.Request.Scheme, HttpContext.Request.Host, HttpContext.Request.Path);
            //    return Redirect(url);

            //}

            //return Redirect("https://dotnettutorials.net");
        }
    }
}