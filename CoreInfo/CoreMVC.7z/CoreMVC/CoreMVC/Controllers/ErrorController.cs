﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace CoreMVC.Controllers
{
    public class ErrorController : Controller
    {
        [Route("Error/{statusCode}")]
        public IActionResult statusCodeError(int statusCode)
        {
            var statusCodeResult = HttpContext.Features.Get<IStatusCodeReExecuteFeature>();

            switch (statusCode)
            {
                case 404:
                    ViewBag.ExceptionMessage = "404 - Not Found";
                    ViewBag.ExceptionPath = statusCodeResult.OriginalPath;
                    ViewBag.QueryString = statusCodeResult.OriginalQueryString;
                    break;


            }
            return View("Not Found");
        }

        [Route("Error")]
        [AllowAnonymous]
        public IActionResult Error()
        {
            var exceptionDetails = HttpContext.Features.Get<IExceptionHandlerFeature>();
            //ViewBag.ExceptionMessage = exceptionDetails.Error.Message;
            //ViewBag.ExceptionStackTrace = exceptionDetails.Error.StackTrace;       
            //return View(exceptionDetails);

            TempData["ProcessMessage"] = exceptionDetails.Error.Message + "//n" + exceptionDetails.Error.StackTrace;
            TempData["displayMessageModal"] = "displayMessageModal";

            string referer = HttpContext.Request.Headers["Referer"].ToString();
            //Uri baseUri = new Uri(referer);

            return Redirect(referer);
        }
    }
}