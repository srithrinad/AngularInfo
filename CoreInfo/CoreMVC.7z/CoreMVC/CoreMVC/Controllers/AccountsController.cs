﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreMVC.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using CoreMVC.Models.Services;
using CoreMVC.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;

namespace CoreMVC.Controllers
{
    public class AccountsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Logout()
        {
            return View();
        }

        public IActionResult Register(int? Id)
        {
            RegisterViewModel usr = new RegisterViewModel();
            if (string.IsNullOrEmpty(Convert.ToString(Id)) || Convert.ToString(Id) == "0")
                ViewData["Title"] = "Add User";
            else
            {
                ViewData["Title"] = "Edit User";
                using (var context = new CoreMVCContext())
                {
                    UserServices sqlData = new UserServices(context);
                    Users Usr = sqlData.Get(Convert.ToInt32(Id));
                    usr.Id = Usr.Id;
                    usr.FirstName = Usr.FirstName;
                    usr.LastName = Usr.LastName;
                    usr.Password = Usr.Password;
                    usr.Email = Usr.Email;
                    usr.DOB = Usr.DOB;
                }
            }

            
            return View(usr);
        }


        public IActionResult EditUser(int Id)
        {            
            return RedirectToAction("Register", new { Id = Id });
        }

        public IActionResult AddUser()
        {
            return RedirectToAction("Register");
        }

        [HttpPost]
        public IActionResult BulkDelete(IFormCollection data)
        {
            List<int> IdList = data["IsChecked"].Select(x => int.Parse(x)).ToList();

            using (var context = new CoreMVCContext())
            {
                UserServices sqlData = new UserServices(context);
                sqlData.DeleteAll(IdList);
            }

            return RedirectToAction("UsersList");
        }

        [HttpPost]
        public IActionResult BulkDelete2(IFormCollection data)
        {
            var k = data["IsChecked"];
            return RedirectToAction("UsersList");
        }

        [HttpPost]
        public IActionResult RegisterAdd(RegisterViewModel Model)
        {
            if (ModelState.IsValid)
            {
                using (var context = new CoreMVCContext())
                {
                    UserServices sqlData = new UserServices(context);

                    Users usr = new Users()
                    {
                        Id=Model.Id,
                        FirstName = Model.FirstName,
                        LastName = Model.LastName,
                        Password = Model.Password,
                        Email = Model.Email,
                        DOB = Model.DOB,
                    };

                    if (Model.Id > 0)
                        sqlData.Update(usr);
                    else                   
                        sqlData.Add(usr);
                   
                }


                return RedirectToAction("UsersList");


            }

            return RedirectToAction("Register");
        }


        [HttpGet]
        public IActionResult UsersList()
        {
            using (var context = new CoreMVCContext())
            {
                UserServices sqlData = new UserServices(context);

                ICollection<Users> UserList = sqlData.GetAll().ToList();

                string json = JsonConvert.SerializeObject(UserList, Formatting.Indented);
                List<RegisterViewModel> objVM = JsonConvert.DeserializeObject<List<RegisterViewModel>>(json);                

                return View(objVM);
            }
        
        }


        public IActionResult DeleteUser(int Id)
        {

            using (var context = new CoreMVCContext())
            {
                UserServices sqlData = new UserServices(context);
                sqlData.Delete(Id);
            }

            return RedirectToAction("UsersList");
        }
    }
}