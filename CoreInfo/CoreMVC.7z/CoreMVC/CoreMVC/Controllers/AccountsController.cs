﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreMVC.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using CoreMVC.Models.Services;
using CoreMVC.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using CoreServices;
using CoreDataAccess;
using CoreDomain;


namespace CoreMVC.Controllers
{
   
    public class AccountsController : Controller
    {
        private readonly IConfiguration configuration;
        public UserService _userService;

        public AccountsController(IConfiguration config,  UserService userService)
        {
            _userService = userService;
            configuration = config;
        }

        public IActionResult Index()
        {
            return View();
        }





        
        public async Task<IActionResult> Register(int? Id)
        {
            RegisterViewModel usr = new RegisterViewModel();
            if (string.IsNullOrEmpty(Convert.ToString(Id)) || Convert.ToString(Id) == "0")
                ViewData["Title"] = "Add User";
            else
            {
                ViewData["Title"] = "Edit User";
                using (var context = new OldCoreMVCContext(configuration))
                {
                     //UserServices sqlData = new UserServices(context);
                    Users Usr = await _userService.FindAsync(Convert.ToInt32(Id));
                   // Users Usr = sqlData.Get(Convert.ToInt32(Id));
                    usr.Id = Usr.Id;
                    usr.FirstName = Usr.FirstName;
                    usr.LastName = Usr.LastName;
                    usr.Password = Usr.Password;
                    usr.Email = Usr.Email;
                    usr.DOB = Usr.DOB;
                }
            }


            return View(usr);
        }

        [Authorize(Policy = "IsAdmin")]
        public IActionResult EditUser(int Id)
        {
            return RedirectToAction("Register", new { Id = Id });
        }

        public IActionResult AddUser()
        {
            return RedirectToAction("Register");
        }

        [HttpPost]
        [Authorize(Policy = "IsAdmin")]
        public async Task<IActionResult> BulkDelete(IFormCollection data)
        {
            List<int> IdList = data["IsChecked"].Select(x => int.Parse(x)).ToList();

            //using (var context = new OldCoreMVCContext(configuration))
            //{
            //    UserServices sqlData = new UserServices(context);
            //    sqlData.DeleteAll(IdList);
            //}

            IEnumerable<Users> usrs = await _userService.GetAll();
            await _userService.Delete(usrs.Where(i => IdList.Contains(i.Id)));

            return RedirectToAction("UsersList");
        }

        [HttpPost]
        public IActionResult BulkDelete2(IFormCollection data)
        {
            var k = data["IsChecked"];
            return RedirectToAction("UsersList");
        }

        [HttpPost]
        public async Task<IActionResult> RegisterAdd(IFormCollection data)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Users usr;

                    //using (var context = new OldCoreMVCContext(configuration))
                    //{
                    //    UserServices sqlData = new UserServices(context);

                    if (Convert.ToInt32(data["Id"]) > 0)
                    {
                        usr = await _userService.FindAsync(Convert.ToInt32(data["Id"]));

                        usr.FirstName = data["FirstName"];
                        usr.LastName = data["LastName"];
                        usr.Email = data["Email"];
                        usr.DOB = Convert.ToDateTime(data["DOB"]);

                        if (Convert.ToString(data["hidPasswordChanged"]) == "1")
                        {
                            usr.Password = data["Password"];
                        }

                        await _userService.UpdateAsync(usr);
                    }
                    else
                    {
                        usr = new Users();
                        usr.Id = Convert.ToInt32(data["Id"]);
                        usr.FirstName = data["FirstName"];
                        usr.LastName = data["LastName"];
                        usr.Email = data["Email"];
                        usr.Password = data["Password"];
                        usr.DOB = Convert.ToDateTime(data["DOB"]);
                        await _userService.InsertAsync(usr);
                    }
                    //}


                    return RedirectToAction("UsersList");


                }

                return RedirectToAction("Register");
            }
            catch(Exception ex)
            {
                throw ex;

            }
        }


        [HttpGet]
        [Authorize(Policy = "IsAdmin")]
        public async Task<IActionResult> UsersList()
        {
            //using (var context = new OldCoreMVCContext(configuration))
            //{
            //    UserServices sqlData = new UserServices(context);

            ICollection<Users> UserList = (await _userService.GetAll()).ToList();



            string json = JsonConvert.SerializeObject(UserList, Formatting.Indented);
            List<RegisterViewModel> objVM = JsonConvert.DeserializeObject<List<RegisterViewModel>>(json);

            if (objVM.Count > 0)
                objVM[0].Permissions = new List<string>() { "p1", "p2", "p3" };


            return View(objVM);
            //}

        }

        [Authorize(Policy = "IsAdmin")]
        public async Task<IActionResult> DeleteUser(int Id)
        {
            Users usr = await _userService.FindAsync(Id);
            await _userService.Delete(usr);

            //using (var context = new OldCoreMVCContext(configuration))
            //{
            //    UserServices sqlData = new UserServices(context);
            //    sqlData.Delete(Id);
            //}

            return RedirectToAction("UsersList");
        }
    }
}