﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreMVC.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using CoreMVC.Models.Services;
using CoreMVC.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace CoreMVC.Controllers
{
    public class AccountsController : Controller
    {
        private readonly IConfiguration configuration;

        public AccountsController(IConfiguration config)
        {
            configuration = config;
        }

        public IActionResult Index()
        {
            return View();
        }






        public IActionResult Register(int? Id)
        {
            RegisterViewModel usr = new RegisterViewModel();
            if (string.IsNullOrEmpty(Convert.ToString(Id)) || Convert.ToString(Id) == "0")
                ViewData["Title"] = "Add User";
            else
            {
                ViewData["Title"] = "Edit User";
                using (var context = new CoreMVCContext(configuration))
                {
                    UserServices sqlData = new UserServices(context);
                    Users Usr = sqlData.Get(Convert.ToInt32(Id));
                    usr.Id = Usr.Id;
                    usr.FirstName = Usr.FirstName;
                    usr.LastName = Usr.LastName;
                    usr.Password = Usr.Password;
                    usr.Email = Usr.Email;
                    usr.DOB = Usr.DOB;
                }
            }


            return View(usr);
        }


        public IActionResult EditUser(int Id)
        {
            return RedirectToAction("Register", new { Id = Id });
        }

        public IActionResult AddUser()
        {
            return RedirectToAction("Register");
        }

        [HttpPost]
        public IActionResult BulkDelete(IFormCollection data)
        {
            List<int> IdList = data["IsChecked"].Select(x => int.Parse(x)).ToList();

            using (var context = new CoreMVCContext(configuration))
            {
                UserServices sqlData = new UserServices(context);
                sqlData.DeleteAll(IdList);
            }

            return RedirectToAction("UsersList");
        }

        [HttpPost]
        public IActionResult BulkDelete2(IFormCollection data)
        {
            var k = data["IsChecked"];
            return RedirectToAction("UsersList");
        }

        [HttpPost]
        public IActionResult RegisterAdd(IFormCollection data)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Users usr;

                    using (var context = new CoreMVCContext(configuration))
                    {
                        UserServices sqlData = new UserServices(context);

                        if (Convert.ToInt32(data["Id"]) > 0)
                        {
                            usr = sqlData.Get(Convert.ToInt32(data["Id"]));

                            usr.FirstName = data["FirstName"];
                            usr.LastName = data["LastName"];
                            usr.Email = data["Email"];
                            usr.DOB = Convert.ToDateTime(data["DOB"]);

                            if (Convert.ToString(data["hidPasswordChanged"]) == "1")
                            {
                                usr.Password = data["Password"];
                            }

                            sqlData.Update(usr);
                        }
                        else
                        {
                            usr = new Users();
                            usr.Id = Convert.ToInt32(data["Id"]);
                            usr.FirstName = data["FirstName"];
                            usr.LastName = data["LastName"];
                            usr.Email = data["Email"];
                            usr.Password = data["Password"];
                            usr.DOB = Convert.ToDateTime(data["DOB"]);
                            sqlData.Add(usr);
                        }
                    }


                    return RedirectToAction("UsersList");


                }

                return RedirectToAction("Register");
            }
            catch(Exception ex)
            {
                throw ex;

            }
        }


        [HttpGet]
        public IActionResult UsersList()
        {
            using (var context = new CoreMVCContext(configuration))
            {
                UserServices sqlData = new UserServices(context);

                ICollection<Users> UserList = sqlData.GetAll().ToList();



                string json = JsonConvert.SerializeObject(UserList, Formatting.Indented);
                List<RegisterViewModel> objVM = JsonConvert.DeserializeObject<List<RegisterViewModel>>(json);

                objVM[0].Permissions = new List<string>() { "p1", "p2", "p3" };


                return View(objVM);
            }

        }


        public IActionResult DeleteUser(int Id)
        {

            using (var context = new CoreMVCContext(configuration))
            {
                UserServices sqlData = new UserServices(context);
                sqlData.Delete(Id);
            }

            return RedirectToAction("UsersList");
        }
    }
}