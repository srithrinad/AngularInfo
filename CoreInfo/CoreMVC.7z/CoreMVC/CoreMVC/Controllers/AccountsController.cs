﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreMVC.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using CoreMVC.Models.Services;
using CoreMVC.Models;

namespace CoreMVC.Controllers
{
    public class AccountsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Logout()
        {
            return View();
        }


        public IActionResult Register(int _viewType)
        {
            ViewData["Title"] = _viewType == 0 ? "Add User" : "Edit User";
            return View();
        }

        [HttpPost]
        public IActionResult RegisterAdd(RegisterViewModel Model)
        {
            if (ModelState.IsValid)
            {
                using (var context = new CoreMVCContext())
                {
                    UserServices sqlData = new UserServices(context);

                    Users usr = new Users()
                    {
                        FirstName = Model.FirstName,
                        LastName = Model.LastName,
                        Password = Model.Password,
                        Email = Model.Email,
                        DOB = Model.DOB,
                    };

                    sqlData.Add(usr);
                }


                return RedirectToAction("Index", "Home");


            }

            return RedirectToAction("Register","0");
        }


        [HttpGet]
        public IActionResult UsersList()
        {
            using (var context = new CoreMVCContext())
            {
                UserServices sqlData = new UserServices(context);

                ICollection<Users> UserList = sqlData.GetAll().ToList();

                return View(UserList);
            }
        
        }


        public IActionResult DeleteUser(int Id)
        {

            using (var context = new CoreMVCContext())
            {
                UserServices sqlData = new UserServices(context);
                sqlData.Delete(Id);
            }

            return RedirectToAction("UsersList");
        }
    }
}