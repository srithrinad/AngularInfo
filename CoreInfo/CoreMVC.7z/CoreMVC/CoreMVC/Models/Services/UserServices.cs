﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Linq;

namespace CoreMVC.Models.Services
{
    public class UserServices
    {
        CoreMVCContext _context { get; set; }

        public UserServices(CoreMVCContext context)
        {
            _context = context;
        }

        public IEnumerable<Users> GetAll()
        {
            return _context.Users.ToList<Users>();
        }

        public Users Get(int Id)
        {
            return _context.Users.FirstOrDefault(column => column.Id == Id);
        }

        public void Add(Users usr)
        {
            _context.Add(usr);
            _context.SaveChanges();
        }


        public void Update(Users usr)
        {
            _context.Update(usr);
            _context.SaveChanges();
        }


        public void Delete(int Id)
        {
            Users usr = _context.Users.FirstOrDefault(column => column.Id == Id);
            _context.Remove(usr);
            _context.SaveChanges();
        }

        public void DeleteAll(List<int> IdList)
        {
            IEnumerable<Users> usr = _context.Users.Where(column => IdList.Contains(column.Id));
            _context.RemoveRange(usr);
            _context.SaveChanges();
        }


    }
}
