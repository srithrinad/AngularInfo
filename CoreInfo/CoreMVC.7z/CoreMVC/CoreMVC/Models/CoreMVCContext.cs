﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;



namespace CoreMVC.Models
{
    public class CoreMVCContext : DbContext
    {
        public CoreMVCContext()
        {
        }

        public CoreMVCContext(DbContextOptions<CoreMVCContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            if (!builder.IsConfigured)
            {
                // string conn = "Data Source=125.62.198.183;Initial Catalog=3nad;User ID=IT-TekDB;Password=u$t@y0ut";
                string conn = "Data Source=Home\\MSSQL2016;Initial Catalog=CoreMVC; User ID=sa;Password=sql@2016";
                builder.UseSqlServer(conn);
            }

            base.OnConfiguring(builder);
        }


        public DbSet<Users> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        }
    }
}
