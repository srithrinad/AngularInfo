﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace CoreMVC.Models
{
    public class OldCoreMVCContext : DbContext
    {
        private readonly IConfiguration configuration;
        public OldCoreMVCContext(IConfiguration config)
        {
            configuration = config;
        }

        public OldCoreMVCContext(DbContextOptions<OldCoreMVCContext> options, IConfiguration config)
            : base(options)
        {
            configuration = config;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            if (!builder.IsConfigured)
            {
                // string connectionString = "Data Source=125.62.198.183;Initial Catalog=3nad;User ID=IT-TekDB;Password=u$t@y0ut";
                // string connectionString = "Data Source=Home\\MSSQL2016;Initial Catalog=CoreMVC; User ID=sa;Password=sql@2016";

                string connectionString = configuration.GetConnectionString("DefaultConnection");

                builder.UseSqlServer(connectionString);
            }

            base.OnConfiguring(builder);
        }


        public DbSet<OldUsers> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        }
    }
}
