﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreMVC.Models.ViewModels
{
    public class RegisterViewModel
    {
        public int Id { get; set; }

        public bool IsChecked { get; set; }

        [DisplayName("First Name")]
        [Required(ErrorMessage = "First Name is required")]
        public string FirstName { get; set; }

        [DisplayName("Last Name")]
        public string LastName { get; set; }

        [DisplayName("Email")]
        [Required(ErrorMessage = "Email is required")]
        [StringLength(50)]
        public string Email { get; set; }


        [DataType(DataType.Password)]
        public string Password { get; set; }

        [DataType(DataType.Password), Compare(nameof(Password))]
        public string ConfirmPassword { get; set; }


        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }



        // : IValidatableObject
        ////public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        ////{
        ////    List<ValidationResult> errormsg = new List<ValidationResult>();
        ////    //if (!IsValidDate(Date))
        ////    //{
        ////    errormsg.Add(new ValidationResult("Date must be within the last year.", new[] { "LastName" }));
        ////    //}
        ////    //if (!IsValidResourceGroup(ResourceGroup))
        ////    //{
        ////    //    results.Add(new ValidationResult($"Invalid resource group"));
        ////    //}

        ////    return errormsg;
        ////}

    }  
}
