﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public static class AppContext1
{
    private static IHttpContextAccessor _httpContextAccessor;

    public static void Configure(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public static HttpContext Current => _httpContextAccessor.HttpContext;
}


public static class SessionExtensions
{
    public static void Set(this ISession session, string key, object value)
    {
        session.SetString(key, JsonConvert.SerializeObject(value));
    }

    public static T Get<T>(this ISession session, string key)
    {
        var value = session.GetString(key);

        return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
    }
}

//How do I store a complex object?
//I’ve got you covered here too.Here’s a quick JSON storage extension to let you store complex objects nice and simple.

//public static class SessionExtensions
//{
//    public static void SetObjectAsJson(this ISession session, string key, object value)
//    {
//        session.SetString(key, JsonConvert.SerializeObject(value));
//    }

//    public static T GetObjectFromJson<T>(this ISession session, string key)
//    {
//        var value = session.GetString(key);

//        return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
//    }
//}
//Now you can store your complex objects like so:

//var myComplexObject = new MyClass();
//HttpContext.Session.SetObjectAsJson("Test", myComplexObject);
//and retrieve them just as easily:

//var myComplexObject = HttpContext.Session.GetObjectFromJson<MyClass>("Test");