﻿using System;
using CoreBase;
using CoreDomain;
using CoreDataAccess;
using System.Threading.Tasks;

namespace CoreServices
{
    public class UserService 
    {
        UserRepository _repository;
        public UserService(UserRepository repository)
        {
            _repository = repository;
        }

        public async Task<Users> Get(int Id)
        {
            return await _repository.FindAsync(Id);
        }

    }
}
