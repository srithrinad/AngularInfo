﻿using System;
using CoreBase;
using CoreDomain;
using CoreDataAccess;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace CoreServices
{
    public class UserService : Repository<Users>
    {

        public UserService(CoreContext coreContext) : base(coreContext)
        {

        }

        public async Task<Users> AuthenticateUser(string Email, string Password)
        {
            IEnumerable<Users> usrs = await GetAll();
            return usrs.ToList().FirstOrDefault<Users>(i => i.Email == Email && i.Password == Password);

        }

    }
}
